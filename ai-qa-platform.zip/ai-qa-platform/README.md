# 🧠 NeuralQ — AI-Powered Q&A Platform

![MERN Stack](https://img.shields.io/badge/Stack-MERN-61DAFB?style=flat-square&logo=react)
![Node.js](https://img.shields.io/badge/Node.js-18+-8CC84B?style=flat-square&logo=node.js)
![MongoDB](https://img.shields.io/badge/MongoDB-Atlas-00ED64?style=flat-square&logo=mongodb)
![License](https://img.shields.io/badge/License-MIT-purple?style=flat-square)

A full-stack AI-powered Q&A web application where users can ask questions and receive structured AI-generated answers with code blocks, bullet points, and headings.

---

## ✨ Features

- 🔐 **Authentication** — JWT-based signup/login with bcrypt password hashing
- 🤖 **AI Responses** — Connects to OpenAI API with smart mock fallback
- 📊 **Structured Output** — Headings, bullet points, syntax-highlighted code blocks
- ⌨️ **Typing Animation** — Character-by-character response rendering
- 📜 **Query History** — All questions and answers saved per user
- 🌙 **Dark / Light Mode** — System preference + manual toggle
- 📱 **Fully Responsive** — Mobile and desktop ready
- ✨ **Framer Motion** — Page transitions and animated UI

---

## 🛠 Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, React Router v6, Framer Motion |
| Styling | Custom CSS with CSS Variables, Responsive |
| Backend | Node.js, Express.js (MVC Architecture) |
| Database | MongoDB + Mongoose |
| Auth | JWT + bcryptjs |
| AI | OpenAI API / HuggingFace / Mock fallback |

---

## 📁 Project Structure

```
ai-qa-platform/
├── backend/
│   ├── config/
│   │   └── db.js                  # MongoDB connection
│   ├── controllers/
│   │   ├── authController.js      # signup, login, getMe
│   │   └── qaController.js        # askQuestion, getHistory, deleteHistory
│   ├── middleware/
│   │   └── authMiddleware.js      # JWT protect middleware
│   ├── models/
│   │   ├── User.js                # User schema (name, email, password)
│   │   └── QA.js                  # Q&A schema (userId, question, response)
│   ├── routes/
│   │   ├── authRoutes.js          # POST /signup, POST /login, GET /me
│   │   └── qaRoutes.js            # POST /ask, GET /history, DELETE /history/:id
│   ├── .env.example
│   ├── package.json
│   └── server.js
│
└── frontend/
    ├── public/
    │   └── index.html
    └── src/
        ├── context/
        │   ├── AuthContext.js     # Global auth state
        │   └── ThemeContext.js    # Dark/light mode state
        ├── components/
        │   ├── Navbar.js          # Navigation with profile dropdown
        │   ├── Navbar.css
        │   ├── ResponseRenderer.js # AI response with typing animation
        │   └── ResponseRenderer.css
        ├── pages/
        │   ├── Home.js            # Landing page with hero + features
        │   ├── Home.css
        │   ├── Login.js           # Login form with validation
        │   ├── Signup.js          # Signup form with validation
        │   ├── AuthPages.css
        │   ├── Dashboard.js       # Main AI Q&A interface
        │   └── Dashboard.css
        ├── App.js                 # Router + PrivateRoute + PublicRoute
        ├── App.css                # Design tokens + global styles
        ├── index.js
        ├── .env.example
        └── package.json
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js v18+
- MongoDB (local or [MongoDB Atlas](https://www.mongodb.com/atlas))
- OpenAI API key (optional — mock fallback works without it)

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/ai-qa-platform.git
cd ai-qa-platform
```

### 2. Setup Backend

```bash
cd backend
npm install
cp .env.example .env
```

Edit `backend/.env`:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/ai_qa_platform
JWT_SECRET=your_super_secret_key_here
OPENAI_API_KEY=your_openai_api_key_here   # optional
NODE_ENV=development
```

Start the backend:

```bash
npm run dev
```

### 3. Setup Frontend

```bash
cd frontend
npm install
cp .env.example .env
```

Edit `frontend/.env`:

```env
REACT_APP_API_URL=http://localhost:5000/api
```

Start the frontend:

```bash
npm start
```

### 4. Open in browser

```
http://localhost:3000
```

---

## 🔌 API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/auth/signup` | ❌ | Register new user |
| POST | `/api/auth/login` | ❌ | Login user |
| GET | `/api/auth/me` | ✅ | Get current user |
| POST | `/api/ask` | ✅ | Ask AI a question |
| GET | `/api/history` | ✅ | Get query history |
| DELETE | `/api/history/:id` | ✅ | Delete a history item |

---

## 🗄️ Database Models

**User**
```js
{ name, email, password (hashed), createdAt }
```

**QA**
```js
{ userId, question, response, source, tokens, createdAt }
```

---

## 🤖 AI Sources

The app tries AI sources in this order:
1. **OpenAI** — if `OPENAI_API_KEY` is set
2. **HuggingFace** — if `HUGGINGFACE_API_KEY` is set
3. **Mock / Demo** — built-in smart responses (always available)

---

## 📜 License

MIT — free to use and modify.

---

## 👤 Author

Built with ❤️ using the MERN stack.
